import React, { useState, useEffect, useRef, Suspense, useMemo } from 'react';
import { 
  Bug, 
  Play, 
  CheckCircle2, 
  Clock, 
  Code2, 
  Cpu, 
  FlaskConical, 
  History, 
  Info, 
  Layout, 
  Lightbulb, 
  RefreshCw, 
  Terminal, 
  ChevronRight,
  Clipboard,
  Check,
  AlertTriangle,
  Zap,
  LogIn,
  LogOut,
  User as UserIcon,
  Shield,
  Search,
  Settings,
  Database,
  Globe,
  Sparkles,
  Command,
  Box as BoxIcon,
  Fingerprint,
  Lock,
  Eye,
  Download,
  Share2,
  Activity,
  ShieldCheck,
  ZapOff,
  BarChart3,
  Server,
  MessageSquare,
  Terminal as TerminalIcon,
  Zap,
  Info
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI, Type } from "@google/genai";
import { Canvas, useFrame } from '@react-three/fiber';
import { Float, Sphere, MeshDistortMaterial, PerspectiveCamera, OrbitControls, Stars, Text, MeshWobbleMaterial, Center } from '@react-three/drei';
import * as THREE from 'three';
import { onAuthStateChanged, User } from 'firebase/auth';
import { collection, query, where, orderBy, limit, getDocs, addDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db, signInWithGoogle, logOut, handleFirestoreError, OperationType } from './lib/firebase';
import { cn } from './lib/utils';
import { FixResult, fixResultSchema, SampleBug, HistoryItem } from './types';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell
} from 'recharts';

// --- Mock Stats for Dashboard ---
const ANALYTICS_DATA = [
  { name: '00:00', patches: 120, latency: 450 },
  { name: '04:00', patches: 80, latency: 420 },
  { name: '08:00', patches: 250, latency: 580 },
  { name: '12:00', patches: 450, latency: 610 },
  { name: '16:00', patches: 380, latency: 590 },
  { name: '20:00', patches: 310, latency: 520 },
  { name: '23:59', patches: 190, latency: 480 },
];

const LANGUAGE_RELIABILITY = [
  { name: 'JS', value: 98, color: '#4f7ef8' },
  { name: 'PY', value: 97, color: '#9060f8' },
  { name: 'CPP', value: 92, color: '#f87171' },
  { name: 'JAVA', value: 95, color: '#fbbf24' },
];

// --- 3D Components ---

function AnimatedSphere() {
  return (
    <group>
      <Float speed={2} rotationIntensity={0.5} floatIntensity={1}>
        <Sphere args={[1, 100, 200]} scale={2}>
          <MeshDistortMaterial
            color="#4f7ef8"
            attach="material"
            distort={0.4}
            speed={1.5}
            roughness={0.1}
            metalness={0.9}
            emissive="#203a7d"
            emissiveIntensity={0.5}
          />
        </Sphere>
      </Float>
      <Float speed={1.5} rotationIntensity={1} floatIntensity={2}>
        <Sphere args={[1, 32, 32]} scale={0.4} position={[3, 2, -2]}>
          <MeshWobbleMaterial color="#9060f8" factor={1} speed={2} metalness={0.8} />
        </Sphere>
      </Float>
      <Float speed={2} rotationIntensity={1} floatIntensity={1.5}>
        <Sphere args={[1, 32, 32]} scale={0.3} position={[-4, -1, 1]}>
          <MeshWobbleMaterial color="#4f7ef8" factor={2} speed={1.5} metalness={0.8} />
        </Sphere>
      </Float>
    </group>
  );
}

function FloatingCube({ position, color, size = 0.5 }: { position: [number, number, number], color: string, size?: number }) {
  const mesh = useRef<THREE.Mesh>(null);
  useFrame((state) => {
    if (mesh.current) {
      mesh.current.rotation.x += 0.01;
      mesh.current.rotation.y += 0.01;
      mesh.current.position.y += Math.sin(state.clock.getElapsedTime() + position[0]) * 0.002;
    }
  });

  return (
    <mesh ref={mesh} position={position}>
      <boxGeometry args={[size, size, size]} />
      <meshStandardMaterial color={color} metalness={0.8} roughness={0.2} transparent opacity={0.6} />
    </mesh>
  );
}

function DataFlow() {
  const points = useRef<THREE.Group>(null);
  useFrame((state) => {
    if (points.current) {
      points.current.rotation.y = state.clock.getElapsedTime() * 0.05;
    }
  });

  return (
    <group ref={points}>
      {Array.from({ length: 20 }).map((_, i) => (
        <FloatingCube 
          key={i} 
          position={[
            (Math.random() - 0.5) * 15,
            (Math.random() - 0.5) * 15,
            (Math.random() - 0.5) * 15
          ]} 
          color={Math.random() > 0.5 ? "#4f7ef8" : "#9060f8"}
          size={Math.random() * 0.3 + 0.1}
        />
      ))}
    </group>
  );
}

function CodeColumn({ x, z, count = 12 }: { x: number, z: number, count?: number }) {
  const group = useRef<THREE.Group>(null);
  const chars = "01<>{}[]/\\*&^%$#@!+=".split("");
  
  const [data] = useState(() => Array.from({ length: count }).map(() => ({
    y: Math.random() * 20 - 10,
    char: chars[Math.floor(Math.random() * chars.length)],
    speed: 0.01 + Math.random() * 0.03,
    glitchRate: 0.02 + Math.random() * 0.05
  })));

  useFrame((state) => {
    if (group.current) {
      group.current.children.forEach((child, i) => {
        const textMesh = child as any;
        // Float down
        textMesh.position.y -= data[i].speed;
        if (textMesh.position.y < -12) textMesh.position.y = 12;

        // Glitch character
        if (Math.random() < data[i].glitchRate) {
          textMesh.text = chars[Math.floor(Math.random() * chars.length)];
        }
        
        // Pulse opacity
        textMesh.fillOpacity = 0.2 + Math.sin(state.clock.getElapsedTime() * 2 + i) * 0.1;
      });
    }
  });

  return (
    <group ref={group} position={[x, 0, z]}>
      {data.map((d, i) => (
        <Text
          key={i}
          position={[0, d.y, 0]}
          fontSize={0.2}
          color="#4f7ef8"
          fillOpacity={0.3}
          font="https://fonts.gstatic.com/s/jetbrainsmono/v18/t6nu489Qp43I7.woff"
        >
          {d.char}
        </Text>
      ))}
    </group>
  );
}

function NeuralNexus() {
  const points = useRef<THREE.Points>(null);
  const linePositions = useMemo(() => {
    const pos = new Float32Array(30 * 3);
    for (let i = 0; i < 30; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 20;
      pos[i * 3 + 1] = (Math.random() - 0.5) * 20;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 10;
    }
    return pos;
  }, []);

  useFrame((state) => {
    if (points.current) {
      points.current.rotation.y = state.clock.getElapsedTime() * 0.05;
      points.current.position.y = Math.sin(state.clock.getElapsedTime() * 0.5) * 0.2;
    }
  });

  return (
    <group>
      <points ref={points}>
        <bufferGeometry>
          <bufferAttribute
            attach="attributes-position"
            count={linePositions.length / 3}
            array={linePositions}
            itemSize={3}
          />
        </bufferGeometry>
        <pointsMaterial size={0.05} color="#4f7ef8" transparent opacity={0.4} />
      </points>
      {/* Bioluminescent particles */}
      <Stars radius={50} depth={50} count={1000} factor={4} saturation={0} fade speed={1} />
    </group>
  );
}

function CodeBackground() {
  const mouse = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      mouse.current.x = (e.clientX / window.innerWidth - 0.5) * 2;
      mouse.current.y = (e.clientY / window.innerHeight - 0.5) * 2;
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <group>
      <ambientLight intensity={0.2} />
      <pointLight position={[10, 10, 10]} intensity={1} color="#4f7ef8" />
      <NeuralNexus />
      <SceneWrapper mouse={mouse} />
    </group>
  );
}

function SceneWrapper({ mouse }: { mouse: React.MutableRefObject<{ x: number, y: number }> }) {
  const ref = useRef<THREE.Group>(null);
  
  useFrame(() => {
    if (ref.current) {
      ref.current.rotation.y = THREE.MathUtils.lerp(ref.current.rotation.y, mouse.current.x * 0.1, 0.05);
      ref.current.rotation.x = THREE.MathUtils.lerp(ref.current.rotation.x, -mouse.current.y * 0.1, 0.05);
    }
  });

  return (
    <group ref={ref}>
      {Array.from({ length: 25 }).map((_, i) => (
        <CodeColumn 
          key={i} 
          x={(Math.random() - 0.5) * 30} 
          z={(Math.random() - 0.5) * 15 - 8}
          count={10}
        />
      ))}
    </group>
  );
}

// --- Constants ---

const SAMPLES: SampleBug[] = [
  {
    id: 'js-fact',
    label: 'Factorial (Infinite Recursion)',
    filename: 'factorial.js',
    language: 'javascript',
    code: `function calculateFactorial(n) {\n  // Bug: Base case returns 0 instead of 1\n  // Bug: Infinite recursion (n - 1 missing)\n  if (n === 0) {\n    return 0;\n  }\n  return n * calculateFactorial(n);\n}`
  },
  {
    id: 'py-fib',
    label: 'Fibonacci (Wrong Base Case)',
    filename: 'fibonacci.py',
    language: 'python',
    code: `def fibonacci(n):\n    # Bug: returns wrong value for n=1\n    if n <= 0:\n        return 0\n    if n == 1:\n        return 0  # Should be 1\n    return fibonacci(n-1) + fibonacci(n-2)`
  },
  {
    id: 'js-bin',
    label: 'Binary Search (Indexing Error)',
    filename: 'binary_search.js',
    language: 'javascript',
    code: `function binarySearch(arr, target) {\n  let low = 0;\n  let high = arr.length;  // Bug: should be length - 1\n  while (low <= high) {\n    let mid = low + high;  // Bug: no division by 2\n    if (arr[mid] === target) return mid;\n    if (arr[mid] < target) low = mid + 1;\n    else high = mid - 1;\n  }\n  return -1;\n}`
  },
  {
    id: 'cpp-swap',
    label: 'Swap (Reference Error)',
    filename: 'swap.cpp',
    language: 'cpp',
    code: `// Bug: parameters should be passed by reference\nvoid swapValues(int a, int b) {\n    int temp = a;\n    a = b;\n    b = temp;\n    // Changes are lost outside this scope\n}`
  }
];

const STEPS = [
  { id: 'ready', label: 'Scan', icon: Search },
  { id: 'analyzing', label: 'Analyze', icon: Bug },
  { id: 'fixing', label: 'Patch', icon: Cpu },
  { id: 'testing', label: 'Verify', icon: FlaskConical },
  { id: 'completed', label: 'Healed', icon: CheckCircle2 }
];

// --- Main App ---

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthLoading, setIsAuthLoading] = useState(true);
  const [loginError, setLoginError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'overview' | 'workspace' | 'history'>('workspace');
  const [currentLang, setCurrentLang] = useState('javascript');
  const [code, setCode] = useState(SAMPLES[0].code);
  const [filename, setFilename] = useState(SAMPLES[0].filename);
  const [status, setStatus] = useState<typeof STEPS[number]['id']>('ready');
  const [result, setResult] = useState<FixResult | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [isCopied, setIsCopied] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [repairError, setRepairError] = useState<string | null>(null);
  const [isVoiceEnabled, setIsVoiceEnabled] = useState(false);
  const [isDiagnosticMode, setIsDiagnosticMode] = useState(true);
  const [chatMessage, setChatMessage] = useState("");
  const [chatLog, setChatLog] = useState<{role: 'user' | 'ai', text: string}[]>([]);
  const [systemLogs, setSystemLogs] = useState<{id: string, text: string, type: 'info' | 'warn' | 'success'}[]>([]);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [chatLog]);

  const addSystemLog = (text: string, type: 'info' | 'warn' | 'success' = 'info') => {
    setSystemLogs(prev => [{ id: Math.random().toString(), text, type }, ...prev].slice(0, 5));
  };

  const speak = (text: string) => {
    if (!isVoiceEnabled) return;
    const synth = window.speechSynthesis;
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.1;
    utterance.pitch = 0.9;
    utterance.volume = 0.5;
    synth.speak(utterance);
  };

  useEffect(() => {
    if (status === 'analyzing') speak("Beginning deep neural scan of source nodes.");
    if (status === 'fixing') speak("Synthesis engine active. Redirecting logic branches.");
    if (status === 'completed') speak("Diagnostic complete. System integrity restored.");
  }, [status, isVoiceEnabled]);

  const aiRef = useRef<GoogleGenAI | null>(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setIsAuthLoading(false);
      if (u) loadUserHistory(u.uid);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (!aiRef.current && process.env.GEMINI_API_KEY) {
      aiRef.current = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    }
  }, []);

  const loadUserHistory = async (uid: string) => {
    try {
      const q = query(
        collection(db, 'repairs'),
        where('userId', '==', uid),
        orderBy('timestamp', 'desc'),
        limit(20)
      );
      const querySnapshot = await getDocs(q);
      const items: HistoryItem[] = [];
      querySnapshot.forEach((doc) => {
        const data = doc.data();
        items.push({
          id: doc.id,
          timestamp: data.timestamp?.toDate().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', day: 'numeric', month: 'short' }) || 'Recent',
          filename: data.filename,
          language: data.language,
          bug: data.detectedBug,
          originalCode: data.originalCode,
          result: {
            detected_bug: data.detectedBug,
            bug_type: data.bugType,
            line_hint: '',
            fixed_code: data.fixedCode,
            fix_explanation: data.explanation,
            confidence: data.confidence,
            test_results: 'Verified from Cloud Vault',
            tests_simulated: []
          }
        });
      });
      setHistory(items);
    } catch (err) {
      handleFirestoreError(err, OperationType.GET, 'repairs');
    }
  };

  const handleLogin = async () => {
    setLoginError(null);
    try {
      await signInWithGoogle();
      addSystemLog("IDENTITY_VERIFIED: GOOGLE_OAUTH", "success");
    } catch (err: any) {
      console.error("Login failure:", err);
      setLoginError(err.message || "Failed to sign in. Please try again.");
    }
  };

  const handleRunFixer = async () => {
    if (!code.trim() || isProcessing || !user) return;
    if (!aiRef.current) {
      setRepairError("AI Engine unavailable. Check API configuration.");
      return;
    }

    setIsProcessing(true);
    setRepairError(null);
    setResult(null);
    
    try {
      setStatus('analyzing');
      addSystemLog("NEURAL_SCAN_INITIATED", "info");
      const langName = { 
        javascript: 'JavaScript', 
        python: 'Python', 
        java: 'Java', 
        cpp: 'C++', 
        typescript: 'TypeScript' 
      }[currentLang] || currentLang;

      const prompt = `Analyze this buggy ${langName} code and produce a precise fix.
      BUGGY CODE:
      \`\`\`${currentLang}
      ${code}
      \`\`\``;

      const responseSchema = {
        type: Type.OBJECT,
        properties: {
          detected_bug: { type: Type.STRING },
          bug_type: { type: Type.STRING },
          line_hint: { type: Type.STRING },
          fixed_code: { type: Type.STRING },
          fix_explanation: { type: Type.STRING },
          confidence: { type: Type.NUMBER },
          test_results: { type: Type.STRING },
          tests_simulated: { type: Type.ARRAY, items: { type: Type.STRING } }
        },
        required: ["detected_bug", "bug_type", "line_hint", "fixed_code", "fix_explanation", "confidence", "test_results", "tests_simulated"]
      };

      await new Promise(r => setTimeout(r, 800));
      setStatus('fixing');

      const response = await aiRef.current.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: responseSchema
        }
      });

      if (!response.text) {
        console.error("Empty response from Gemini");
        throw new Error("Neural synthesis node returned empty response.");
      }
      
      const rawData = JSON.parse(response.text);
      const validation = fixResultSchema.safeParse(rawData);
      
      if (!validation.success) {
        console.error("Validation error:", validation.error);
        throw new Error("Received malformed synthesis payload. Structure integrity failed.");
      }

      const fixData = validation.data;

      setStatus('testing');
      addSystemLog("PATCH_SYNTHESIS_COMPLETE", "success");
      await new Promise(r => setTimeout(r, 1000));

      // Save to Firestore
      try {
        await addDoc(collection(db, 'repairs'), {
          userId: user.uid,
          filename,
          language: currentLang,
          originalCode: code,
          detectedBug: fixData.detected_bug,
          bugType: fixData.bug_type,
          fixedCode: fixData.fixed_code,
          explanation: fixData.fix_explanation,
          confidence: fixData.confidence,
          timestamp: serverTimestamp()
        });
        addSystemLog("DIAGNOSTIC_CLOUD_SYNC", "success");
      } catch (e) {
        handleFirestoreError(e, OperationType.WRITE, 'repairs');
      }

      setStatus('completed');
      setResult(fixData);
      loadUserHistory(user.uid);

    } catch (err: any) {
      setRepairError(err.message || "Neural synthesis failure.");
      setStatus('ready');
    } finally {
      setIsProcessing(false);
    }
  };

  const copyToClipboard = () => {
    if (result) {
      navigator.clipboard.writeText(result.fixed_code);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    }
  };

  const handleDownload = () => {
    if (!result) return;
    const blob = new Blob([result.fixed_code], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `healed_${filename}`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const handleShare = async () => {
    if (!result) return;
    try {
      await navigator.share({
        title: 'Sentinel Code Patch',
        text: `Fixed a bug in ${filename} using Code Sentinel AI.`,
        url: window.location.href,
      });
    } catch (err) {
      // Share API might not be available
      copyToClipboard();
    }
  };

  if (isAuthLoading) {
    return (
      <div className="h-screen w-screen bg-[#0d0d0f] flex flex-col items-center justify-center gap-4">
        <motion.div animate={{ scale: [1, 1.2, 1], opacity: [0.5, 1, 0.5] }} transition={{ repeat: Infinity, duration: 2 }}>
          <Zap className="w-12 h-12 text-[#4f7ef8] fill-[#4f7ef8]/20" />
        </motion.div>
        <span className="text-[10px] font-black uppercase tracking-[0.3em] text-[#606078] animate-pulse">Syncing Neural Core</span>
      </div>
    );
  }

  if (!user) {
    return (
    <div className={cn(
      "min-h-screen bg-[#0d0d0f] text-white overflow-hidden relative selection:bg-blue-500/30",
      isDiagnosticMode && "diagnostic-scanlines"
    )}>
      {/* Global Grain Effect */}
      <div className="fixed inset-0 pointer-events-none opacity-[0.05] z-[100] bg-[url('https://grainy-gradients.vercel.app/noise.svg')]"></div>
      
      <div className="absolute inset-0 z-0">
          <Canvas dpr={[1, 2]}>
            <PerspectiveCamera makeDefault position={[0, 0, 8]} />
            <Stars radius={150} depth={80} count={7000} factor={6} saturation={0} fade speed={2} />
            <ambientLight intensity={0.5} />
            <pointLight position={[10, 10, 10]} intensity={1.5} color="#4f7ef8" />
            <pointLight position={[-10, -10, -10]} intensity={0.8} color="#9060f8" />
            <Suspense fallback={null}>
              <AnimatedSphere />
              <DataFlow />
            </Suspense>
            <OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={0.8} />
          </Canvas>
        </div>

        <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-6 py-20 text-center">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
            className="space-y-8 max-w-4xl"
          >
            <div className="mx-auto flex items-center justify-center w-16 h-16 border rounded-2xl bg-[#4f7ef8]/10 border-[#4f7ef8]/40 shadow-[0_0_30px_rgba(79,126,248,0.2)] mb-8">
              <Zap className="w-8 h-8 text-[#4f7ef8] fill-[#4f7ef8]/20" />
            </div>

            <div className="space-y-4">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.3 }}
                className="inline-flex items-center gap-2 px-4 py-1.5 bg-blue-500/10 border border-blue-500/20 rounded-full text-blue-400 text-xs font-black uppercase tracking-[0.2em] backdrop-blur-xl"
              >
                <Sparkles className="w-3.5 h-3.5" /> Neural Defense System v3.0
              </motion.div>
              
              <h1 className="text-7xl md:text-9xl font-black tracking-tighter leading-none">
                <span className="block">CODE</span>
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-purple-400 to-indigo-500 italic drop-shadow-sm">SENTINEL</span>
              </h1>
            </div>
            
            <p className="text-[#9090a8] text-xl md:text-2xl max-w-2xl mx-auto font-medium leading-tight px-4">
              Advanced autonomous program repair. 
              <span className="text-white"> Scan. Heal. Secure.</span>
              <br />
              <span className="text-blue-400 text-sm mt-4 block">Available on Desktop, iOS, and Android via PWA Install.</span>
            </p>

            <div className="pt-12 space-y-6">
              <motion.button
                whileHover={{ scale: 1.02, y: -2 }}
                whileTap={{ scale: 0.98 }}
                onClick={handleLogin}
                className="group relative inline-flex items-center gap-4 px-10 py-5 bg-white text-black rounded-[2rem] font-black text-xl overflow-hidden transition-all shadow-[0_20px_50px_rgba(0,0,0,0.3)] hover:shadow-[0_0_60px_rgba(79,126,248,0.5)]"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-purple-500/20 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                <div className="relative flex items-center gap-4">
                  <LogIn className="w-6 h-6 animate-pulse" />
                  INITIATE SYSTEM GATE
                </div>
              </motion.button>
              
              {loginError && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-4 bg-red-500/10 border border-red-500/30 rounded-2xl text-red-400 text-xs font-bold max-w-md mx-auto"
                >
                  <AlertTriangle className="w-4 h-4 inline-block mr-2" />
                  AUTH_FAULT: {loginError}
                </motion.div>
              )}

              <div className="flex items-center justify-center gap-8 pt-8">
                {[
                  { label: "Neural Net", val: "GEMINI 3.1 PRO" },
                  { label: "Verification", val: "ISOLATED CORE" },
                  { label: "Uptime", val: "99.9% SL" }
                ].map((item, idx) => (
                  <div key={idx} className="text-left">
                    <p className="text-[9px] font-black uppercase text-[#606078] tracking-widest">{item.label}</p>
                    <p className="text-xs font-bold text-[#e8e8f0]">{item.val}</p>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div className={cn(
      "min-h-screen bg-[#0d0d0f] text-[#e8e8f0] font-sans selection:bg-[#4f7ef8]/30 overflow-x-hidden relative",
      isDiagnosticMode && "diagnostic-scanlines"
    )}>
      {/* Global Grain Effect */}
      <div className="fixed inset-0 pointer-events-none opacity-[0.05] z-[100] bg-[url('https://grainy-gradients.vercel.app/noise.svg')]"></div>
      
      {/* HUD Accents */}
      <div className="fixed top-1/2 left-4 -translate-y-1/2 z-[60] flex flex-col gap-8 opacity-20 hidden 2xl:flex pointer-events-none">
         <div className="w-1 h-32 bg-blue-500/30 rounded-full overflow-hidden">
            <motion.div animate={{ y: ["-100%", "100%"] }} transition={{ duration: 4, repeat: Infinity, ease: "linear" }} className="w-full h-1/2 bg-blue-400 shadow-[0_0_10px_#4f7ef8]"></motion.div>
         </div>
      </div>
      <div className="fixed top-1/2 right-4 -translate-y-1/2 z-[60] flex flex-col gap-8 opacity-20 hidden 2xl:flex pointer-events-none">
         <div className="w-1 h-32 bg-blue-500/30 rounded-full overflow-hidden">
            <motion.div animate={{ y: ["100%", "-100%"] }} transition={{ duration: 5, repeat: Infinity, ease: "linear" }} className="w-full h-1/2 bg-blue-400 shadow-[0_0_10px_#4f7ef8]"></motion.div>
         </div>
      </div>

      <nav className="sticky top-0 z-50 px-6 py-4 flex items-center justify-between border-b border-[#2a2a35] bg-[#0d0d0f]/90 backdrop-blur-xl">
        <div className="flex items-center gap-4">
          <div className="flex items-center justify-center w-11 h-11 border rounded-2xl bg-blue-500/10 border-blue-500/40 shadow-[0_0_20px_rgba(79,126,248,0.2)]">
            <Command className="w-6 h-6 text-[#4f7ef8]" />
          </div>
          <div className="hidden sm:block">
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-black tracking-tighter">SENTINEL<span className="text-[#4f7ef8]">_OS</span></h1>
              <span className="px-2 py-0.5 bg-green-500/10 border border-green-500/20 rounded text-[8px] font-black text-green-400 uppercase tracking-widest">Placement_Ready</span>
            </div>
            <p className="text-[10px] uppercase tracking-[0.2em] text-[#606078] font-black leading-none mt-1">Cloud Core V3.0</p>
          </div>
        </div>

        <div className="flex bg-[#141417] p-1 rounded-2xl border border-[#2a2a35]">
          {(['overview', 'workspace', 'history'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={cn(
                "px-5 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all flex items-center gap-2",
                activeTab === tab 
                  ? "bg-[#2a2a35] text-[#4f7ef8] shadow-lg" 
                  : "text-[#606078] hover:text-white"
              )}
            >
              {tab === 'workspace' ? <Terminal className="w-3.5 h-3.5" /> : tab === 'overview' ? <Layout className="w-3.5 h-3.5" /> : <History className="w-3.5 h-3.5" />}
              <span className="hidden md:inline">{tab}</span>
            </button>
          ))}
        </div>

        <div className="flex items-center gap-4">
           <button 
             onClick={() => {
               setIsVoiceEnabled(!isVoiceEnabled);
               if (!isVoiceEnabled) speak("Voice synthesis protocol initialized.");
             }}
             className={cn(
               "p-2.5 rounded-xl border transition-all flex items-center gap-2",
               isVoiceEnabled 
                 ? "bg-blue-500/10 border-blue-500 text-blue-400 shadow-[0_0_15px_rgba(79,126,248,0.3)]" 
                 : "bg-[#141417] border-[#2a2a35] text-[#606078] hover:text-white"
             )}
             title="Neural Voice Toggle"
           >
             <Activity className={cn("w-4 h-4", isVoiceEnabled && "animate-pulse")} />
             <span className="text-[10px] font-black uppercase tracking-widest hidden sm:inline">Voice_Link</span>
           </button>

           <div className="flex items-center gap-3 px-3 py-1.5 bg-[#141417] rounded-full border border-[#2a2a35]">
              <img src={user.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.email}`} alt="pfp" className="w-6 h-6 rounded-full ring-1 ring-blue-500/30" />
              <button 
                onClick={logOut}
                className="p-1 text-[#606078] hover:text-red-500 transition-colors"
                title="Disconnect Node"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
           </div>
        </div>
      </nav>

      <main className="max-w-[1600px] mx-auto p-6 lg:p-10">
        <AnimatePresence mode="wait">
          {activeTab === 'workspace' && (
            <motion.div 
              key="workspace"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8 relative"
            >
              {/* 3D Workspace Background */}
              <div className="fixed inset-0 pointer-events-none opacity-20 z-0 overflow-hidden">
                <Canvas dpr={[1, 1.5]}>
                   <PerspectiveCamera makeDefault position={[0, 0, 10]} />
                   <CodeBackground />
                </Canvas>
              </div>

              <div className="relative z-10 space-y-8">
                <div className="grid grid-cols-5 gap-4 px-10 py-8 bg-[#141417]/80 backdrop-blur-md border border-[#2a2a35] rounded-[3rem] relative shadow-2xl overflow-hidden group">
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 via-transparent to-purple-500/5"></div>
                {STEPS.map((step, idx) => {
                  const Icon = step.icon;
                  const isDone = STEPS.findIndex(s => s.id === status) > idx || status === 'completed';
                  const isActive = status === step.id;
                  
                  return (
                    <div key={step.id} className="flex flex-col items-center gap-4 group/step relative z-10 text-center">
                      <div className={cn(
                        "w-14 h-14 rounded-2xl flex items-center justify-center border-2 transition-all duration-700 relative",
                        isDone ? "bg-[#4f7ef8] border-[#4f7ef8] text-white scale-110 shadow-[0_10px_30px_rgba(79,126,248,0.4)]" : 
                        isActive ? "bg-[#4f7ef8]/10 border-[#4f7ef8] text-[#4f7ef8] shadow-[0_0_40px_rgba(79,126,248,0.3)]" : 
                        "bg-[#1a1a1f] border-[#2a2a35] text-[#606078]"
                      )}>
                        <Icon className={cn("w-6 h-6", isActive && "animate-pulse")} />
                      </div>
                      <div className="space-y-1">
                        <span className={cn(
                          "text-[10px] font-black uppercase tracking-[0.3em] transition-colors",
                          isDone || isActive ? "text-white" : "text-[#606078]"
                        )}>{step.label}</span>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="grid grid-cols-1 xl:grid-cols-12 gap-8 items-stretch">
                <div className="xl:col-span-3 space-y-6">
                  {/* System Log Ticker */}
                  <div className="bg-[#141417]/80 backdrop-blur-md border border-[#2a2a35] rounded-2xl p-4 font-mono text-[8px] flex flex-col gap-2 min-h-[140px] relative z-30">
                     <div className="flex items-center justify-between border-b border-[#2a2a35] pb-2 mb-1">
                        <span className="text-[#4f7ef8] font-black uppercase">System_Events</span>
                        <Info className="w-3 h-3 text-[#606078]" />
                     </div>
                     <div className="space-y-2 overflow-hidden h-[80px]">
                        {systemLogs.length === 0 && <div className="text-[#303040]">_NO_LOGS_RECORDED_</div>}
                        {systemLogs.map(log => (
                          <div key={log.id} className="flex items-start gap-2 animate-in slide-in-from-left duration-300">
                             <span className="text-[#404050]">[{new Date().toLocaleTimeString([], { hour12: false })}]</span>
                             <span className={cn(
                               "font-bold uppercase",
                               log.type === 'success' ? "text-green-500" : log.type === 'warn' ? "text-red-500" : "text-blue-400"
                             )}>{log.text}</span>
                          </div>
                        ))}
                     </div>
                  </div>

                  {/* Neural terminal Console */}
                  <div className="bg-[#141417]/80 backdrop-blur-md border border-[#2a2a35] rounded-[2rem] p-6 h-[400px] flex flex-col shadow-xl relative z-20 group">
                    <div className="flex items-center gap-2 mb-4">
                      <TerminalIcon className="w-3.5 h-3.5 text-[#4f7ef8]" />
                      <h3 className="text-[10px] font-black uppercase tracking-[0.3em] text-[#606078]">Neural_Console</h3>
                    </div>
                    
                    <div className="flex-1 overflow-y-auto space-y-4 mb-4 scrollbar-hide text-[10px] font-mono">
                       {chatLog.length === 0 && (
                         <div className="text-[#404050] italic px-2">Console idle. Awaiting instruction...</div>
                       )}
                       {chatLog.map((msg, i) => (
                         <div key={i} className={cn(
                           "p-3 rounded-xl border",
                           msg.role === 'ai' ? "bg-blue-500/5 border-blue-500/20 text-[#9090a8]" : "bg-[#1a1a1f] border-[#2a2a35] text-white"
                         )}>
                            <div className="flex items-center gap-2 mb-1 opacity-50">
                               {msg.role === 'ai' ? <Sparkles className="w-2.5 h-2.5" /> : <Fingerprint className="w-2.5 h-2.5" />}
                               <span className="uppercase text-[8px] font-black tracking-widest">{msg.role}</span>
                            </div>
                            {msg.text}
                         </div>
                       ))}
                       <div ref={chatEndRef} />
                    </div>

                    <div className="relative">
                       <input 
                         type="text"
                         value={chatMessage}
                         onChange={(e) => setChatMessage(e.target.value)}
                          onKeyDown={async (e) => {
                           if (e.key === 'Enter' && chatMessage) {
                             const userMsg = chatMessage;
                             setChatLog(prev => [...prev, { role: 'user', text: userMsg }]);
                             setChatMessage("");
                             
                             try {
                               const genAI = aiRef.current || new GoogleGenAI(process.env.GEMINI_API_KEY!);
                               const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
                               const result = await model.generateContent(`As Code Sentinel AI, answer this developer query concisely: ${userMsg}`);
                               const response = result.response.text();
                               
                               setChatLog(prev => [...prev, { role: 'ai', text: response }]);
                               speak(response.slice(0, 100) + "...");
                               addSystemLog("CONSOLE_QUERY_RESOLVED", "success");
                             } catch (err) {
                               setChatLog(prev => [...prev, { role: 'ai', text: "Neural link disrupted. Check network protocol." }]);
                               addSystemLog("LINK_TIMEOUT", "warn");
                             }
                           }
                         }}
                         placeholder="Type directive..."
                         className="w-full bg-[#1a1a1f] border border-[#2a2a35] rounded-xl px-4 py-3 text-[10px] text-white placeholder-[#404050] focus:border-[#4f7ef8] outline-none transition-all"
                       />
                       <Zap className="absolute right-4 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#4f7ef8]/40" />
                    </div>
                  </div>

                  <div className="bg-[#141417]/80 backdrop-blur-md border border-[#2a2a35] rounded-[2rem] p-6 space-y-6 shadow-xl relative z-20">
                    <div className="space-y-4">
                      <h3 className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.3em] text-[#606078] px-1">
                        <Globe className="w-3.5 h-3.5" /> Language
                      </h3>
                      <div className="grid grid-cols-1 gap-2">
                        {['javascript', 'python', 'java', 'cpp'].map(lang => (
                          <button
                            key={lang}
                            onClick={() => setCurrentLang(lang)}
                            className={cn(
                              "px-5 py-4 rounded-2xl text-xs font-black uppercase tracking-widest border transition-all text-left flex items-center justify-between group",
                              currentLang === lang 
                                ? "bg-[#4f7ef8] border-[#4f7ef8] text-white" 
                                : "bg-[#1a1a1f] border-[#2a2a35] text-[#606078] hover:text-[#9090a8]"
                            )}
                          >
                            {lang.toUpperCase()}
                            <ChevronRight className={cn("w-3.5 h-3.5", currentLang === lang ? "translate-x-1" : "")} />
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-4 border-t border-[#2a2a35] pt-6">
                      <h3 className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.3em] text-[#606078] px-1">
                        <Zap className="w-3.5 h-3.5" /> Defect Repository
                      </h3>
                      <div className="space-y-2">
                        {SAMPLES.filter(s => s.language === currentLang).map(sample => (
                          <button
                            key={sample.id}
                            onClick={() => {
                              setCode(sample.code);
                              setFilename(sample.filename);
                              setResult(null);
                              setStatus('ready');
                            }}
                            className="w-full text-left p-4 rounded-2xl bg-[#1a1a1f]/50 border border-[#2a2a35] hover:border-[#4f7ef8]/40 transition-all flex items-center justify-between group"
                          >
                            <div>
                              <span className="text-xs font-bold text-[#e8e8f0] block group-hover:text-[#4f7ef8]">{sample.label}</span>
                              <span className="text-[10px] text-[#606078] mt-1 font-mono block">{sample.filename}</span>
                            </div>
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="xl:col-span-6 space-y-6">
                  <div className="relative group/editor h-full">
                    <div className="absolute -inset-1 bg-gradient-to-r from-blue-500/20 via-purple-500/20 to-indigo-500/20 rounded-[2.5rem] blur opacity-30 group-hover/editor:opacity-60 transition duration-1000"></div>
                    <div className="relative bg-[#141417]/80 backdrop-blur-md border border-[#2a2a35] rounded-[2.5rem] h-full overflow-hidden flex flex-col shadow-2xl">
                      {/* Scanning Overlay */}
                      <AnimatePresence>
                        {(status === 'analyzing' || status === 'fixing') && (
                          <motion.div 
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            className="absolute inset-0 z-40 pointer-events-none"
                          >
                            <div className="absolute inset-0 bg-blue-500/5 animate-pulse"></div>
                            <motion.div 
                              animate={{ y: ["0%", "100%", "0%"] }}
                              transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                              className="w-full h-px bg-gradient-to-r from-transparent via-blue-500 to-transparent shadow-[0_0_15px_rgba(79,126,248,0.8)]"
                            ></motion.div>
                            <div className="absolute inset-0 flex items-center justify-center">
                               <div className="w-64 h-64 border border-blue-500/20 rounded-full animate-[spin_10s_linear_infinite]"></div>
                               <div className="absolute w-48 h-48 border border-blue-500/10 rounded-full animate-[spin_15s_linear_infinite_reverse]"></div>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>

                      <div className="flex items-center justify-between px-8 py-5 bg-[#1a1a1f]/50 border-b border-[#2a2a35]">
                        <div className="flex items-center gap-4">
                          <div className="flex gap-2">
                             <div className="w-3 h-3 rounded-full bg-red-500/30"></div>
                             <div className="w-3 h-3 rounded-full bg-yellow-500/30"></div>
                             <div className="w-3 h-3 rounded-full bg-green-500/30"></div>
                          </div>
                          <span className="text-[10px] font-mono font-bold text-[#606078] tracking-[0.3em] uppercase">{filename}</span>
                        </div>
                        <motion.button 
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          onClick={handleRunFixer}
                          disabled={isProcessing}
                          className={cn(
                            "flex items-center gap-3 px-8 py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-[0.3em] transition-all",
                            isProcessing 
                              ? "bg-[#1a1a1f] text-[#606078]" 
                              : "bg-[#4f7ef8] text-white shadow-[0_0_30px_rgba(79,126,248,0.4)] hover:bg-[#3d6be0]"
                          )}
                        >
                           {isProcessing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
                           Initiate Healing
                        </motion.button>
                      </div>
                      <div className="flex-1 relative">
                        <textarea
                          value={code}
                          onChange={(e) => setCode(e.target.value)}
                          spellCheck={false}
                          className="w-full h-full p-10 bg-transparent text-[#d4d4e8] font-mono text-base leading-relaxed focus:outline-none resize-none overflow-y-auto"
                          placeholder="// Inject buggy symbol stream for deep scanning..."
                        />
                      </div>
                    </div>
                  </div>
                  
                  {repairError && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-6 bg-red-500/10 border border-red-500/20 rounded-[2rem] flex items-center gap-4 text-red-500 text-sm font-black uppercase tracking-widest shadow-lg"
                    >
                      <AlertTriangle className="w-6 h-6 flex-shrink-0" />
                      REPAIR_FAULT: {repairError}
                    </motion.div>
                  )}
                </div>

                <div className="xl:col-span-3 space-y-6">
                  <div className="bg-[#141417]/80 backdrop-blur-md border border-[#2a2a35] rounded-[2.5rem] h-full flex flex-col shadow-2xl relative overflow-hidden">
                    <div className="px-8 py-6 border-b border-[#2a2a35] flex items-center justify-between">
                      <h3 className="text-[10px] font-black uppercase tracking-[0.3em] text-[#606078] flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-[#4f7ef8]" /> Synthesis
                      </h3>
                      {result && (
                        <div className="flex gap-2">
                          <button onClick={handleDownload} className="p-2 bg-[#1a1a1f] border border-[#2a2a35] rounded-xl text-[#606078] hover:text-[#4f7ef8] transition-colors" title="Download Patch">
                            <Download className="w-4 h-4" />
                          </button>
                          <button onClick={handleShare} className="p-2 bg-[#1a1a1f] border border-[#2a2a35] rounded-xl text-[#606078] hover:text-[#4f7ef8] transition-colors" title="Share Diagnostics">
                            <Share2 className="w-4 h-4" />
                          </button>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex-1 p-8 overflow-y-auto">
                        {!result && !isProcessing && (
                          <div className="h-full flex flex-col items-center justify-center text-center opacity-30">
                            <BoxIcon className="w-16 h-16 mb-4 text-[#606078]" />
                            <p className="text-[10px] font-black uppercase tracking-[0.4em] text-[#606078]">Core Standby</p>
                          </div>
                        )}

                        {isProcessing && (
                          <div className="h-full flex flex-col items-center justify-center text-center space-y-8 py-10">
                            <div className="relative">
                              <div className="w-20 h-20 border-[6px] border-[#1a1a1f] rounded-full"></div>
                              <motion.div 
                                animate={{ rotate: 360 }}
                                transition={{ repeat: Infinity, duration: 1, ease: 'linear' }}
                                className="absolute inset-0 border-[6px] border-t-[#4f7ef8] border-r-transparent border-b-transparent border-l-transparent rounded-full"
                              />
                            </div>
                            <p className="text-xs font-black uppercase tracking-[0.5em] text-[#4f7ef8] animate-pulse">
                              {status === 'analyzing' ? 'REASONING' : status === 'fixing' ? 'SPLICING' : 'VERIFYING'}
                            </p>
                          </div>
                        )}

                        {result && (
                          <motion.div 
                            initial={{ opacity: 0, x: 20 }}
                            animate={{ opacity: 1, x: 0 }}
                            className="space-y-8"
                          >
                            <div className="space-y-4">
                              <div className="flex items-center justify-between">
                                <label className="text-[9px] font-black uppercase tracking-[.4em] text-[#606078]">Analysis</label>
                                <span className="bg-[#4f7ef8]/10 text-[#4f7ef8] px-3 py-1 rounded-full text-[9px] font-black">{result.bug_type}</span>
                              </div>
                              <div className="p-5 bg-[#1a1a1f] border border-[#2a2a35] rounded-3xl text-sm leading-relaxed text-[#9090a8] font-medium italic border-l-4 border-l-[#4f7ef8]">
                                "{result.detected_bug}"
                              </div>
                            </div>

                            <div className="space-y-4">
                              <div className="flex items-center justify-between">
                                <label className="text-[9px] font-black uppercase tracking-[.4em] text-[#606078]">Fixed Code</label>
                                <button 
                                  onClick={copyToClipboard}
                                  className="p-2 rounded-xl bg-[#1a1a1f] border border-[#2a2a35] text-[#606078] hover:text-[#4f7ef8]"
                                >
                                  {isCopied ? <Check className="w-4 h-4 text-green-500" /> : <Clipboard className="w-4 h-4" />}
                                </button>
                              </div>
                              <pre className="p-6 bg-[#09090b] border border-[#2a2a35] rounded-3xl text-[10px] font-mono leading-relaxed text-blue-200/90 overflow-x-auto">
                                {result.fixed_code}
                              </pre>
                            </div>

                            <div className="space-y-2">
                               <div className="flex items-center justify-between">
                                 <span className="text-[9px] font-black uppercase tracking-[.4em] text-[#606078]">Confidence</span>
                                 <span className="text-sm font-black text-green-500">{result.confidence}%</span>
                               </div>
                               <div className="h-1.5 bg-[#1a1a1f] rounded-full overflow-hidden">
                                 <motion.div 
                                   initial={{ width: 0 }}
                                   animate={{ width: `${result.confidence}%` }}
                                   className="h-full bg-blue-500"
                                   transition={{ duration: 1 }}
                                 />
                               </div>
                            </div>
                          </motion.div>
                        )}
                    </div>
                  </div>
                </div>
                {/* Neural Node Log */}
                <div className="bg-[#141417]/50 border border-[#2a2a35] rounded-[2rem] p-6 font-mono text-[9px] text-[#606078] grid grid-cols-2 lg:grid-cols-4 gap-6 relative z-30 mt-8 mb-8">
                  {[
                    { label: "NODE_STATUS", val: isProcessing ? "ACTIVE_SYNC" : "IDLE", color: isProcessing ? "text-blue-400" : "text-[#606078]" },
                    { label: "VOICE_LINK", val: isVoiceEnabled ? "ENCRYPTED" : "DISABLED", color: isVoiceEnabled ? "text-green-400" : "text-[#606078]" },
                    { label: "SYST_LATENCY", val: "12ms", color: "text-[#606078]" },
                    { label: "MODEL_LAYER", val: "GEMINI_3.1_FLASH", color: "text-[#606078]" }
                  ].map((log, i) => (
                    <div key={i} className="flex flex-col gap-1">
                      <span className="text-[8px] font-black tracking-widest opacity-40">{log.label}</span>
                      <span className={cn("font-bold", log.color)}>{log.val}</span>
                    </div>
                  ))}
                </div>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'history' && (
             <motion.div 
               key="history"
               initial={{ opacity: 0, scale: 0.98 }}
               animate={{ opacity: 1, scale: 1 }}
               exit={{ opacity: 0, scale: 0.98 }}
               className="space-y-10 py-10"
             >
                <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-[#2a2a35] pb-10">
                  <div className="space-y-2">
                    <h2 className="text-5xl font-black tracking-tighter">CENTRAL ARCHIVE.</h2>
                    <p className="text-[#606078] text-lg font-medium tracking-tight">Records of every repair performed by your node.</p>
                  </div>
                  <div className="px-6 py-4 bg-[#141417] border border-[#2a2a35] rounded-[2rem] flex items-center gap-6 shadow-xl">
                    <div className="text-center">
                       <p className="text-[9px] font-black uppercase text-[#606078] tracking-[0.2em] mb-1">Repairs</p>
                       <span className="text-2xl font-black text-[#4f7ef8]">{history.length}</span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                  {history.map((item, idx) => (
                    <motion.button
                      key={item.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.05 }}
                      whileHover={{ y: -8 }}
                      onClick={() => {
                        setCode(item.originalCode);
                        setResult(item.result);
                        setStatus('completed');
                        setCurrentLang(item.language);
                        setFilename(item.filename);
                        setActiveTab('workspace');
                      }}
                      className="group text-left bg-[#141417] border border-[#2a2a35] rounded-[2.5rem] p-8 transition-all"
                    >
                      <div className="space-y-6">
                        <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest text-[#606078]">
                          <span>{item.language}</span>
                          <span>{item.timestamp}</span>
                        </div>
                        <div>
                          <h4 className="font-black text-lg text-white group-hover:text-[#4f7ef8] transition-colors">{item.filename}</h4>
                          <p className="text-sm text-[#9090a8] line-clamp-2 mt-2 italic">"{item.bug}"</p>
                        </div>
                        <div className="pt-6 border-t border-[#2a2a35] flex items-center justify-between">
                           <span className="text-xs font-black text-green-500">{item.result.confidence}% Trust</span>
                           <ChevronRight className="w-5 h-5 text-[#2a2a35] group-hover:text-[#4f7ef8]" />
                        </div>
                      </div>
                    </motion.button>
                  ))}
                  {history.length === 0 && (
                    <div className="col-span-full py-20 text-center opacity-30">
                       <p className="text-lg font-black uppercase tracking-[0.5em] text-[#606078]">No Records Found</p>
                    </div>
                  )}
                </div>
             </motion.div>
          )}

          {activeTab === 'overview' && (
            <motion.div 
              key="overview"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="py-16 space-y-24"
            >
              {/* Pillar Visualization */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                {[
                  { id: '01', title: 'NEURAL_INTEGRITY', desc: 'Secure patch synthesis via strictly-typed Zod boundaries.', icon: ShieldCheck, color: 'text-blue-400' },
                  { id: '02', title: 'SENTINEL_HANDSHAKE', desc: 'OAuth-driven persistent security across nodes.', icon: Fingerprint, color: 'text-purple-400' },
                  { id: '03', title: 'REALTIME_TELEMETRY', desc: 'Live monitoring of global repair latency & nodes.', icon: Activity, color: 'text-green-400' },
                  { id: '04', title: 'ISOLATED_CORE', desc: 'Air-gapped verification reducing production risk.', icon: Server, color: 'text-orange-400' }
                ].map((p) => (
                  <div key={p.id} className="p-10 bg-[#141417] border border-[#2a2a35] rounded-[3rem] relative group overflow-hidden">
                    <div className="absolute top-0 right-0 p-8 text-4xl font-black text-white/5 group-hover:text-white/10 transition-colors uppercase italic">{p.id}</div>
                    <p.icon className={cn("w-10 h-10 mb-6", p.color)} />
                    <h4 className="text-sm font-black tracking-[0.2em] text-white mb-3 uppercase">{p.title}</h4>
                    <p className="text-xs text-[#606078] leading-relaxed line-clamp-3">{p.desc}</p>
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
                <div className="lg:col-span-8 space-y-12">
                   <div className="space-y-6">
                     <h2 className="text-6xl md:text-8xl font-black leading-[0.9] tracking-tighter">Diagnostic Analytics.</h2>
                     <p className="text-[#9090a8] text-xl font-medium leading-tight max-w-xl">
                       Live telemetry from the global Sentinel network. Monitoring synthesis accuracy and repair throughput.
                     </p>
                   </div>

                   <div className="bg-[#141417] border border-[#2a2a35] rounded-[3rem] p-10 h-[500px] relative overflow-hidden flex flex-col">
                      <div className="flex items-center justify-between mb-10">
                        <div className="flex items-center gap-3">
                           <BarChart3 className="w-5 h-5 text-[#4f7ef8]" />
                           <h3 className="text-[10px] font-black uppercase tracking-[0.4em] text-[#606078]">Global Repair Traffic (24h)</h3>
                        </div>
                        <span className="text-[10px] font-black text-green-500 uppercase tracking-widest flex items-center gap-2">
                           <Activity className="w-3 h-3" /> Live
                        </span>
                      </div>
                      <div className="flex-1 min-h-0">
                        <ResponsiveContainer width="100%" height="100%">
                          <AreaChart data={ANALYTICS_DATA}>
                            <defs>
                              <linearGradient id="colorPatches" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="#4f7ef8" stopOpacity={0.3}/>
                                <stop offset="95%" stopColor="#4f7ef8" stopOpacity={0}/>
                              </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" stroke="#2a2a35" vertical={false} />
                            <XAxis 
                              dataKey="name" 
                              stroke="#606078" 
                              fontSize={10} 
                              tickLine={false} 
                              axisLine={false} 
                            />
                            <YAxis 
                              stroke="#606078" 
                              fontSize={10} 
                              tickLine={false} 
                              axisLine={false}
                              tickFormatter={(value) => `${value}`}
                            />
                            <Tooltip 
                              contentStyle={{ backgroundColor: '#141417', border: '1px solid #2a2a35', borderRadius: '12px' }}
                              itemStyle={{ color: '#4f7ef8' }}
                            />
                            <Area 
                              type="monotone" 
                              dataKey="patches" 
                              stroke="#4f7ef8" 
                              strokeWidth={3}
                              fillOpacity={1} 
                              fill="url(#colorPatches)" 
                              animationDuration={2000}
                            />
                          </AreaChart>
                        </ResponsiveContainer>
                      </div>
                   </div>
                </div>

                <div className="lg:col-span-4 space-y-8">
                   <div className="bg-[#141417] border border-[#2a2a35] rounded-[3rem] p-10 space-y-10">
                      <h3 className="text-[10px] font-black uppercase tracking-[0.4em] text-[#606078]">Synthesis Trust Index</h3>
                      <div className="h-[300px]">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={LANGUAGE_RELIABILITY}>
                            <XAxis 
                              dataKey="name" 
                              stroke="#606078" 
                              fontSize={10} 
                              tickLine={false} 
                              axisLine={false} 
                            />
                            <YAxis hide />
                            <Tooltip 
                               contentStyle={{ backgroundColor: '#141417', border: '1px solid #2a2a35', borderRadius: '12px' }}
                            />
                            <Bar dataKey="value" radius={[10, 10, 10, 10]} barSize={40}>
                              {LANGUAGE_RELIABILITY.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.color} opacity={0.8} />
                              ))}
                            </Bar>
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                      <div className="space-y-4">
                        {LANGUAGE_RELIABILITY.map(lang => (
                          <div key={lang.name} className="flex items-center justify-between">
                            <span className="text-[10px] font-black text-[#606078] uppercase">{lang.name} PROTOCOL</span>
                            <span className="text-xs font-black text-white">{lang.value}% ACCURACY</span>
                          </div>
                        ))}
                      </div>
                   </div>

                   <div className="relative group">
                      <div className="absolute -inset-10 bg-blue-500/10 rounded-full blur-[100px] opacity-40"></div>
                      <div className="relative bg-[#141417] border border-[#2a2a35] rounded-[3rem] p-10 overflow-hidden shadow-2xl flex flex-col gap-8">
                         <div className="space-y-4">
                           <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-[#4f7ef8]">SECURE_STORAGE</h4>
                           <div className="space-y-3">
                             {[
                               { label: 'Cloud Vault', val: 'FIRESTORE', icon: Database },
                               { label: 'Identity', val: 'GOOGLE_OAUTH', icon: Fingerprint },
                               { label: 'Transmission', val: 'TLSv1.3', icon: Lock }
                             ].map((s, i) => (
                               <div key={i} className="flex items-center justify-between p-4 bg-[#1a1a1f] rounded-2xl border border-[#2a2a35]">
                                 <div className="flex items-center gap-3">
                                   <s.icon className="w-3.5 h-3.5 text-[#606078]" />
                                   <span className="text-[9px] font-black text-[#606078] uppercase tracking-widest">{s.label}</span>
                                 </div>
                                 <span className="text-[9px] font-black text-white">{s.val}</span>
                               </div>
                             ))}
                           </div>
                         </div>
                      </div>
                   </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <footer className="mt-40 border-t border-[#2a2a35] py-20 px-8 relative bg-[#09090b]">
        <div className="max-w-[1600px] mx-auto grid grid-cols-1 md:grid-cols-4 gap-20">
          <div className="md:col-span-2 space-y-6">
            <h1 className="font-black text-2xl tracking-tighter">SENTINEL<span className="text-[#4f7ef8]">_OS</span></h1>
            <p className="text-[#606078] text-lg font-medium max-w-sm">
              Decentralized program repair architecture leveraging state-of-the-art neural splicing.
            </p>
          </div>
          <div className="space-y-4">
             <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-white">System</h4>
             <ul className="text-sm font-bold text-[#606078] space-y-2">
                <li>_Neural Core</li>
                <li>_Synthesis Lab</li>
                <li>_Records</li>
             </ul>
          </div>
        </div>
        <div className="max-w-[1600px] mx-auto pt-20 mt-20 border-t border-[#2a2a35] flex flex-col md:flex-row justify-between items-center gap-4">
          <span className="text-[9px] font-black text-[#606078] uppercase tracking-[0.5em]">© 2026 Sentinel_Corp // core_v3.0</span>
          <div className="flex items-center gap-4">
            <div className="w-2 h-2 rounded-full bg-[#4f7ef8] animate-pulse"></div>
            <span className="text-[10px] font-black text-[#4f7ef8] uppercase tracking-[0.3em] flex items-center gap-2">
              <span className="opacity-40">SYST_DIRECTOR:</span> aadityapasi1611@gmail.com
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
}
