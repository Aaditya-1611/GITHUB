import { z } from 'zod';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FixResult {
  detected_bug: string;
  bug_type: string;
  line_hint: string;
  fixed_code: string;
  fix_explanation: string;
  confidence: number;
  test_results: string;
  tests_simulated: string[];
}

export const fixResultSchema = z.object({
  detected_bug: z.string().min(1),
  bug_type: z.string().min(1),
  line_hint: z.string(),
  fixed_code: z.string().min(1),
  fix_explanation: z.string().min(1),
  confidence: z.number().min(0).max(100),
  test_results: z.string(),
  tests_simulated: z.array(z.string())
});

export interface SampleBug {
  id: string;
  label: string;
  filename: string;
  language: string;
  code: string;
}

export interface HistoryItem {
  id: string;
  timestamp: string;
  filename: string;
  language: string;
  bug: string;
  originalCode: string;
  result: FixResult;
}
