/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, Suspense } from 'react';
import { 
  Bug, 
  Play, 
  CheckCircle2, 
  Clock, 
  Code2, 
  Cpu, 
  FlaskConical, 
  History, 
  Info, 
  Layout, 
  Lightbulb, 
  RefreshCw, 
  Terminal, 
  ChevronRight,
  Clipboard,
  Check,
  AlertTriangle,
  Zap,
  LogIn,
  LogOut,
  User as UserIcon,
  Shield,
  Search,
  Settings,
  Database
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI, Type } from "@google/genai";
import { Canvas, useFrame } from '@react-three/fiber';
import { Float, Sphere, MeshDistortMaterial, PerspectiveCamera, OrbitControls, Stars } from '@react-three/drei';
import * as THREE from 'three';
import { onAuthStateChanged, User } from 'firebase/auth';
import { collection, query, where, orderBy, limit, getDocs, addDoc, serverTimestamp, doc, getDocFromServer } from 'firebase/firestore';
import { auth, db, signInWithGoogle, logOut, handleFirestoreError, OperationType } from './lib/firebase';
import { cn } from './lib/utils';

// --- Types ---

interface SampleBug {
  id: string;
  label: string;
  filename: string;
  language: string;
  code: string;
}

interface FixResult {
  detected_bug: string;
  bug_type: string;
  line_hint: string;
  fixed_code: string;
  fix_explanation: string;
  confidence: number;
  test_results: string;
  tests_simulated: string[];
}

interface HistoryItem {
  id: string;
  timestamp: string;
  filename: string;
  language: string;
  bug: string;
  originalCode: string;
  result: FixResult;
}

// --- 3D Components ---

function AnimatedSphere() {
  return (
    <Float speed={4} rotationIntensity={1} floatIntensity={2}>
      <Sphere args={[1, 100, 200]} scale={2.4}>
        <MeshDistortMaterial
          color="#4f7ef8"
          attach="material"
          distort={0.5}
          speed={2}
          roughness={0.2}
          metalness={0.8}
        />
      </Sphere>
    </Float>
  );
}

function CodeRings() {
  const rings = useRef<THREE.Group>(null);
  useFrame((state) => {
    if (rings.current) {
      rings.current.rotation.y = state.clock.getElapsedTime() * 0.1;
      rings.current.rotation.z = state.clock.getElapsedTime() * 0.05;
    }
  });

  return (
    <group ref={rings}>
      {[2, 3.5, 5].map((radius, i) => (
        <mesh key={i} rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[radius, 0.02, 16, 100]} />
          <meshBasicMaterial color="#4f7ef8" transparent opacity={0.2} />
        </mesh>
      ))}
    </group>
  );
}

// --- Constants ---

const SAMPLES: SampleBug[] = [
  {
    id: 'js-fact',
    label: 'Factorial (Infinite Recursion)',
    filename: 'factorial.js',
    language: 'javascript',
    code: `function calculateFactorial(n) {\n  // Bug: Base case returns 0 instead of 1\n  // Bug: Infinite recursion (n - 1 missing)\n  if (n === 0) {\n    return 0;\n  }\n  return n * calculateFactorial(n);\n}`
  },
  {
    id: 'py-fib',
    label: 'Fibonacci (Wrong Base Case)',
    filename: 'fibonacci.py',
    language: 'python',
    code: `def fibonacci(n):\n    # Bug: returns wrong value for n=1\n    if n <= 0:\n        return 0\n    if n == 1:\n        return 0  # Should be 1\n    return fibonacci(n-1) + fibonacci(n-2)`
  },
  {
    id: 'js-bin',
    label: 'Binary Search (Indexing Error)',
    filename: 'binary_search.js',
    language: 'javascript',
    code: `function binarySearch(arr, target) {\n  let low = 0;\n  let high = arr.length;  // Bug: should be length - 1\n  while (low <= high) {\n    let mid = low + high;  // Bug: no division by 2\n    if (arr[mid] === target) return mid;\n    if (arr[mid] < target) low = mid + 1;\n    else high = mid - 1;\n  }\n  return -1;\n}`
  },
  {
    id: 'cpp-swap',
    label: 'Swap (Reference Error)',
    filename: 'swap.cpp',
    language: 'cpp',
    code: `// Bug: parameters should be passed by reference\nvoid swapValues(int a, int b) {\n    int temp = a;\n    a = b;\n    b = temp;\n    // Changes are lost outside this scope\n}`
  }
];

const STEPS = [
  { id: 'ready', label: 'Scan', icon: Search },
  { id: 'analyzing', label: 'Analyze', icon: Bug },
  { id: 'fixing', label: 'Patch', icon: Cpu },
  { id: 'testing', label: 'Verify', icon: FlaskConical },
  { id: 'completed', label: 'Healed', icon: CheckCircle2 }
];

// --- Main App ---

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthLoading, setIsAuthLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'overview' | 'workspace' | 'history'>('workspace');
  const [currentLang, setCurrentLang] = useState('javascript');
  const [code, setCode] = useState(SAMPLES[0].code);
  const [filename, setFilename] = useState(SAMPLES[0].filename);
  const [status, setStatus] = useState<typeof STEPS[number]['id']>('ready');
  const [result, setResult] = useState<FixResult | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [isCopied, setIsCopied] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const aiRef = useRef<GoogleGenAI | null>(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setIsAuthLoading(false);
      if (u) loadUserHistory(u.uid);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (!aiRef.current && process.env.GEMINI_API_KEY) {
      aiRef.current = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    }
  }, []);

  const loadUserHistory = async (uid: string) => {
    try {
      const q = query(
        collection(db, 'repairs'),
        where('userId', '==', uid),
        orderBy('timestamp', 'desc'),
        limit(10)
      );
      const querySnapshot = await getDocs(q);
      const items: HistoryItem[] = [];
      querySnapshot.forEach((doc) => {
        const data = doc.data();
        items.push({
          id: doc.id,
          timestamp: data.timestamp?.toDate().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) || 'Recent',
          filename: data.filename,
          language: data.language,
          bug: data.detectedBug,
          originalCode: data.originalCode,
          result: {
            detected_bug: data.detectedBug,
            bug_type: data.bugType,
            line_hint: '',
            fixed_code: data.fixedCode,
            fix_explanation: data.explanation,
            confidence: data.confidence,
            test_results: 'Verified from Cloud',
            tests_simulated: []
          }
        });
      });
      setHistory(items);
    } catch (err) {
      console.error("Error loading history:", err);
    }
  };

  const handleRunFixer = async () => {
    if (!code.trim() || isProcessing || !user) return;
    if (!aiRef.current) {
      setError("AI API key Not Found.");
      return;
    }

    setIsProcessing(true);
    setError(null);
    setResult(null);
    
    try {
      setStatus('analyzing');
      const langName = { 
        javascript: 'JavaScript', 
        python: 'Python', 
        java: 'Java', 
        cpp: 'C++', 
        typescript: 'TypeScript' 
      }[currentLang] || currentLang;

      const prompt = `Analyze this buggy ${langName} code and produce a precise fix.\n\nCODE:\n\`\`\`${currentLang}\n${code}\n\`\`\``;

      const responseSchema = {
        type: Type.OBJECT,
        properties: {
          detected_bug: { type: Type.STRING },
          bug_type: { type: Type.STRING },
          line_hint: { type: Type.STRING },
          fixed_code: { type: Type.STRING },
          fix_explanation: { type: Type.STRING },
          confidence: { type: Type.NUMBER },
          test_results: { type: Type.STRING },
          tests_simulated: { type: Type.ARRAY, items: { type: Type.STRING } }
        },
        required: ["detected_bug", "bug_type", "line_hint", "fixed_code", "fix_explanation", "confidence", "test_results", "tests_simulated"]
      };

      await new Promise(r => setTimeout(r, 1000));
      setStatus('fixing');

      const response = await aiRef.current.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: responseSchema
        }
      });

      if (!response.text) throw new Error("Empty response from AI");
      const fixData: FixResult = JSON.parse(response.text);

      setStatus('testing');
      await new Promise(r => setTimeout(r, 1200));

      // Save to Firestore
      try {
        await addDoc(collection(db, 'repairs'), {
          userId: user.uid,
          filename,
          language: currentLang,
          originalCode: code,
          detectedBug: fixData.detected_bug,
          bugType: fixData.bug_type,
          fixedCode: fixData.fixed_code,
          explanation: fixData.fix_explanation,
          confidence: fixData.confidence,
          timestamp: serverTimestamp()
        });
      } catch (e) {
        handleFirestoreError(e, OperationType.CREATE, 'repairs');
      }

      setStatus('completed');
      setResult(fixData);
      loadUserHistory(user.uid);

    } catch (err: any) {
      setError(err.message || "An unexpected error occurred.");
      setStatus('ready');
    } finally {
      setIsProcessing(false);
    }
  };

  const copyToClipboard = () => {
    if (result) {
      navigator.clipboard.writeText(result.fixed_code);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    }
  };

  if (isAuthLoading) {
    return (
      <div className="h-screen w-screen bg-[#0d0d0f] flex items-center justify-center">
        <motion.div animate={{ scale: [1, 1.2, 1], opacity: [0.5, 1, 0.5] }} transition={{ repeat: Infinity, duration: 2 }}>
          <Zap className="w-12 h-12 text-[#4f7ef8] fill-[#4f7ef8]/20" />
        </motion.div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-[#0d0d0f] text-white overflow-hidden relative font-display">
        {/* 3D Background */}
        <div className="absolute inset-0 z-0">
          <Canvas>
            <PerspectiveCamera makeDefault position={[0, 0, 5]} />
            <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />
            <ambientLight intensity={0.5} />
            <pointLight position={[10, 10, 10]} intensity={1} color="#4f7ef8" />
            <pointLight position={[-10, -10, -10]} intensity={0.5} color="#9060f8" />
            <Suspense fallback={null}>
              <AnimatedSphere />
              <CodeRings />
            </Suspense>
            <OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={0.5} />
          </Canvas>
        </div>

        {/* Floating UI */}
        <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-6 text-center">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-6 max-w-3xl"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-500/10 border border-blue-500/30 rounded-full text-blue-400 text-xs font-bold uppercase tracking-widest backdrop-blur-xl">
              <Zap className="w-3.5 h-3.5 fill-blue-400/20" /> Autonomous Program Repair v2.0
            </div>
            
            <h1 className="text-6xl md:text-8xl font-black tracking-tighter leading-none">
              CODE <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500 italic">SENTINEL</span>
            </h1>
            
            <p className="text-[#9090a8] text-lg md:text-xl max-w-xl mx-auto font-light leading-relaxed">
              The next generation of AI-driven debugging. Secure your codebase with neural-patching technology.
            </p>

            <div className="pt-10">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={signInWithGoogle}
                className="group relative inline-flex items-center gap-3 px-8 py-4 bg-white text-black rounded-2xl font-bold text-lg overflow-hidden transition-all shadow-[0_0_30px_rgba(255,255,255,0.2)] hover:shadow-[0_0_50px_rgba(79,126,248,0.4)]"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-blue-100 to-purple-100 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                <div className="relative flex items-center gap-3">
                  <LogIn className="w-5 h-5" />
                  Sign in with Google
                </div>
              </motion.button>
              <p className="text-[10px] text-[#606078] mt-6 uppercase tracking-[0.2em] font-bold">Encrypted via Google Cloud Auth</p>
            </div>
          </motion.div>
        </div>

        <div className="absolute bottom-10 left-0 right-0 z-10 flex justify-center gap-10 opacity-30 text-[10px] font-bold uppercase tracking-widest text-[#606078]">
          <span className="flex items-center gap-2"><Shield className="w-3 h-3" /> Zero-Trust Security</span>
          <span className="flex items-center gap-2"><Database className="w-3 h-3" /> Real-time Sync</span>
          <span className="flex items-center gap-2"><Cpu className="w-3 h-3" /> Neural Repair</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0d0d0f] text-[#e8e8f0] font-sans selection:bg-[#4f7ef8]/30">
      {/* Navigation Header */}
      <nav className="sticky top-0 z-50 flex items-center justify-between px-6 py-4 border-b border-[#2a2a35] bg-[#0d0d0f]/80 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center w-10 h-10 border rounded-xl bg-blue-500/10 border-blue-500/50 shadow-[0_0_15px_rgba(79,126,248,0.2)]">
            <Zap className="w-6 h-6 text-[#4f7ef8] fill-[#4f7ef8]/20" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight">Code <span className="text-[#4f7ef8]">Sentinel</span></h1>
            <p className="text-[10px] uppercase tracking-[0.1em] text-[#606078] font-semibold leading-none mt-0.5">Autonomous OS Core</p>
          </div>
        </div>

        <div className="flex bg-[#1a1a1f] p-1 rounded-xl border border-[#2a2a35]">
          {(['overview', 'workspace', 'history'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={cn(
                "px-4 py-1.5 rounded-lg text-xs font-medium transition-all flex items-center gap-2",
                activeTab === tab 
                  ? "bg-[#2a2a35] text-[#4f7ef8] shadow-sm" 
                  : "text-[#9090a8] hover:text-white"
              )}
            >
              {tab === 'overview' && <Layout className="w-3.5 h-3.5" />}
              {tab === 'workspace' && <Terminal className="w-3.5 h-3.5" />}
              {tab === 'history' && <History className="w-3.5 h-3.5" />}
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-4">
           <div className="flex items-center gap-2 px-3 py-1.5 bg-[#1a1a1f] rounded-xl border border-[#2a2a35]">
              <img src={user.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.email}`} alt="pfp" className="w-5 h-5 rounded-full" />
              <span className="text-xs font-medium text-[#9090a8] hidden sm:inline">{user.displayName?.split(' ')[0]}</span>
              <button 
                onClick={logOut}
                className="ml-2 p-1 hover:text-red-400 transition-colors"
                title="Log Out"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
           </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto p-6">
        <AnimatePresence mode="wait">
          {activeTab === 'workspace' && (
            <motion.div 
              key="workspace"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              {/* Status Stepper */}
              <div className="flex items-center justify-between px-8 py-6 bg-[#141417] border border-[#2a2a35] rounded-[2rem] relative overflow-hidden group">
                <div className="absolute inset-0 bg-blue-500/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                {STEPS.map((step, idx) => {
                  const Icon = step.icon;
                  const isDone = STEPS.findIndex(s => s.id === status) > idx || status === 'completed';
                  const isActive = status === step.id;
                  
                  return (
                    <React.Fragment key={step.id}>
                      <div className="flex flex-col items-center gap-2 relative z-10">
                        <div className={cn(
                          "w-12 h-12 rounded-2xl flex items-center justify-center border-2 transition-all duration-500",
                          isDone ? "bg-[#4f7ef8] border-[#4f7ef8] text-white" : 
                          isActive ? "bg-[#1a1a1f] border-[#4f7ef8] text-[#4f7ef8] shadow-[0_0_20px_rgba(79,126,248,0.3)]" : 
                          "bg-[#1a1a1f] border-[#2a2a35] text-[#606078]"
                        )}>
                          <Icon className="w-5 h-5" />
                        </div>
                        <span className={cn(
                          "text-[10px] font-black uppercase tracking-[0.2em] transition-colors",
                          isDone || isActive ? "text-[#e8e8f0]" : "text-[#606078]"
                        )}>{step.label}</span>
                      </div>
                      {idx < STEPS.length - 1 && (
                        <div className="flex-1 h-[2px] bg-[#2a2a35] mb-6 overflow-hidden max-w-[120px]">
                          <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: isDone ? '100%' : isActive ? '50%' : '0%' }}
                            className="h-full bg-gradient-to-r from-[#4f7ef8] to-purple-500"
                            transition={{ duration: 0.8 }}
                          />
                        </div>
                      )}
                    </React.Fragment>
                  );
                })}
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                <div className="lg:col-span-3 space-y-6">
                  <div className="bg-[#141417] border border-[#2a2a35] rounded-2xl p-5">
                    <h3 className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-[#606078] mb-4">
                      <Settings className="w-3.5 h-3.5" /> Language Config
                    </h3>
                    <div className="grid grid-cols-1 gap-2">
                      {['javascript', 'python', 'java', 'cpp'].map(lang => (
                        <button
                          key={lang}
                          onClick={() => setCurrentLang(lang)}
                          className={cn(
                            "px-4 py-2.5 rounded-xl text-xs font-semibold border transition-all text-left flex items-center justify-between",
                            currentLang === lang 
                              ? "bg-[#4f7ef8]/10 border-[#4f7ef8]/50 text-[#4f7ef8]" 
                              : "bg-[#1a1a1f] border-[#2a2a35] text-[#9090a8] hover:border-[#4f7ef8]/30"
                          )}
                        >
                          {lang === 'cpp' ? 'C++' : lang.charAt(0).toUpperCase() + lang.slice(1)}
                          {currentLang === lang && <div className="w-1.5 h-1.5 rounded-full bg-[#4f7ef8] animate-pulse"></div>}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="bg-[#141417] border border-[#2a2a35] rounded-2xl p-5">
                    <h3 className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-[#606078] mb-4">
                      <Zap className="w-3.5 h-3.5" /> Load Test Case
                    </h3>
                    <div className="space-y-2">
                      {SAMPLES.filter(s => s.language === currentLang).map(sample => (
                        <button
                          key={sample.id}
                          onClick={() => {
                            setCode(sample.code);
                            setFilename(sample.filename);
                            setResult(null);
                            setStatus('ready');
                          }}
                          className="w-full group text-left p-4 rounded-xl bg-[#1a1a1f] border border-[#2a2a35] hover:border-[#4f7ef8]/50 transition-all"
                        >
                          <span className="text-xs font-bold text-[#e8e8f0] block group-hover:text-[#4f7ef8] transition-colors">{sample.label}</span>
                          <span className="text-[10px] text-[#606078] mt-1 font-mono block">/src/{sample.filename}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="lg:col-span-12 xl:col-span-6 space-y-4">
                  <div className="relative group">
                    <div className="absolute -inset-1 bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-[2rem] blur opacity-0 group-hover:opacity-100 transition duration-1000"></div>
                    <div className="relative bg-[#141417] border border-[#2a2a35] rounded-[2rem] overflow-hidden shadow-2xl">
                      <div className="flex items-center justify-between px-6 py-4 bg-[#1a1a1f] border-b border-[#2a2a35]">
                        <div className="flex items-center gap-4">
                          <div className="flex gap-1.5">
                            <div className="w-3 h-3 rounded-full bg-[#ff5f56]/20 border border-[#ff5f56]/50"></div>
                            <div className="w-3 h-3 rounded-full bg-[#ffbd2e]/20 border border-[#ffbd2e]/50"></div>
                            <div className="w-3 h-3 rounded-full bg-[#27c93f]/20 border border-[#27c93f]/50"></div>
                          </div>
                          <span className="text-[10px] font-mono font-bold text-[#606078] tracking-widest">SENTINEL_PROCESS_v2.0 // {filename}</span>
                        </div>
                        <button 
                          onClick={handleRunFixer}
                          disabled={isProcessing}
                          className={cn(
                            "flex items-center gap-2 px-6 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all",
                            isProcessing 
                              ? "bg-[#1a1a1f] text-[#606078] cursor-not-allowed" 
                              : "bg-[#4f7ef8] text-white hover:bg-[#3d6be0] shadow-[0_0_20px_rgba(79,126,248,0.4)]"
                          )}
                        >
                          {isProcessing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4 fill-white/20" />}
                          Heal Code
                        </button>
                      </div>
                      <textarea
                        value={code}
                        onChange={(e) => setCode(e.target.value)}
                        spellCheck={false}
                        className="w-full min-h-[500px] p-8 bg-transparent text-blue-100/90 font-mono text-sm leading-relaxed focus:outline-none resize-none scrollbar-thin overflow-y-auto"
                        placeholder="// Enter your buggy code here..."
                      />
                    </div>
                  </div>
                  
                  {error && (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="p-5 bg-red-500/10 border border-red-500/20 rounded-2xl flex items-center gap-3 text-red-400 text-xs font-bold"
                    >
                      <AlertTriangle className="w-5 h-5 flex-shrink-0" />
                      SYSTEM_FAULT: {error}
                    </motion.div>
                  )}
                </div>

                <div className="lg:col-span-12 xl:col-span-3">
                  <div className="bg-[#141417] border border-[#2a2a35] rounded-[2rem] h-full overflow-hidden flex flex-col shadow-xl">
                    <div className="px-6 py-4 bg-[#1a1a1f] border-b border-[#2a2a35] flex items-center justify-between">
                      <h3 className="text-[10px] font-black uppercase tracking-widest text-[#606078] flex items-center gap-2">
                        <Cpu className="w-3.5 h-3.5" /> Neural Node
                      </h3>
                    </div>
                    
                    <div className="flex-1 p-6 overflow-y-auto custom-scrollbar">
                      <AnimatePresence mode="wait">
                        {!result && !isProcessing && (
                          <div className="h-full flex flex-col items-center justify-center text-center py-20">
                            <div className="relative mb-6">
                              <BoxIcon className="w-16 h-16 text-[#2a2a35]/50 animate-pulse" />
                              <div className="absolute inset-0 bg-blue-500/5 blur-2xl"></div>
                            </div>
                            <p className="text-xs font-bold uppercase tracking-widest text-[#606078]">Core Idle</p>
                            <p className="text-[11px] text-[#606078]/80 mt-2 max-w-[140px] font-light">Awaiting input stream for synthesis.</p>
                          </div>
                        )}

                        {isProcessing && (
                          <div className="h-full flex flex-col items-center justify-center text-center space-y-6 py-20">
                            <div className="relative">
                              <div className="w-20 h-20 border-[6px] border-[#2a2a35] rounded-full"></div>
                              <motion.div 
                                animate={{ rotate: 360 }}
                                transition={{ repeat: Infinity, duration: 1, ease: 'linear' }}
                                className="absolute inset-0 border-[6px] border-t-[#4f7ef8] border-r-transparent border-b-transparent border-l-transparent rounded-full shadow-[0_0_15px_rgba(79,126,248,0.5)]"
                              />
                              <Cpu className="w-8 h-8 text-[#4f7ef8] absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
                            </div>
                            <div className="space-y-1.5">
                              <p className="text-xs font-black uppercase tracking-[0.3em] text-[#4f7ef8] animate-pulse">
                                {status.toUpperCase()}
                              </p>
                              <p className="text-[9px] text-[#606078] uppercase tracking-widest font-black">Scanning Tensors</p>
                            </div>
                          </div>
                        )}

                        {result && (
                          <motion.div 
                            key="result"
                            initial={{ opacity: 0, x: 20 }}
                            animate={{ opacity: 1, x: 0 }}
                            className="space-y-6"
                          >
                            <div className="space-y-3">
                              <div className="flex items-center justify-between">
                                <label className="text-[9px] font-black uppercase tracking-[.2em] text-[#606078]">Diagnosis</label>
                                <span className={cn(
                                  "px-2 py-0.5 rounded-full text-[8px] font-bold uppercase tracking-tighter",
                                  result.bug_type.toLowerCase().includes('recursion') ? 'bg-red-500/10 text-red-500 border border-red-500/20' : 'bg-amber-500/10 text-amber-500 border border-amber-500/20'
                                )}>{result.bug_type}</span>
                              </div>
                              <div className="p-4 bg-[#1a1a1f] border border-[#2a2a35] rounded-2xl text-[11px] leading-relaxed text-[#9090a8] font-medium border-l-2 border-l-[#4f7ef8]">
                                {result.detected_bug}
                              </div>
                            </div>

                            <div className="space-y-3">
                              <div className="flex items-center justify-between">
                                <label className="text-[9px] font-black uppercase tracking-[.2em] text-[#606078]">Synthesized Patch</label>
                                <button 
                                  onClick={copyToClipboard}
                                  className="p-1.5 rounded-lg bg-[#1a1a1f] border border-[#2a2a35] text-[#606078] hover:text-[#4f7ef8] transition-colors"
                                >
                                  {isCopied ? <Check className="w-3 h-3 text-green-500" /> : <Clipboard className="w-3 h-3" />}
                                </button>
                              </div>
                              <pre className="p-4 bg-[#0d0d0f] border border-[#2a2a35] rounded-2xl text-[10px] font-mono leading-relaxed text-blue-300 overflow-x-auto">
                                {result.fixed_code}
                              </pre>
                            </div>

                            <div className="space-y-3">
                               <label className="text-[9px] font-black uppercase tracking-[.2em] text-[#606078]">Heal Rationale</label>
                               <p className="text-[11px] text-[#606078] leading-relaxed italic">
                                 "{result.fix_explanation}"
                               </p>
                            </div>

                            <div className="pt-6 border-t border-[#2a2a35] space-y-4">
                               <div className="flex items-center justify-between">
                                 <span className="text-[9px] font-black uppercase text-[#606078]">Integrity Sync</span>
                                 <span className="text-[10px] font-bold text-green-400">{result.confidence}%</span>
                               </div>
                               <div className="h-1 bg-[#1a1a1f] rounded-full overflow-hidden">
                                 <motion.div 
                                   initial={{ width: 0 }}
                                   animate={{ width: `${result.confidence}%` }}
                                   className="h-full bg-gradient-to-r from-blue-500 to-green-400"
                                 />
                               </div>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'history' && (
             <motion.div 
               key="history"
               initial={{ opacity: 0, y: 10 }}
               animate={{ opacity: 1, y: 0 }}
               exit={{ opacity: 0, y: -10 }}
               className="space-y-8"
             >
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <h2 className="text-3xl font-black tracking-tight">Records Vault</h2>
                    <p className="text-[#9090a8] text-sm">Reviewing persistent neural repair logs.</p>
                  </div>
                  <div className="flex items-center gap-4 text-xs font-bold text-[#606078] uppercase tracking-widest">
                    <span>Total Repairs</span>
                    <span className="px-3 py-1 bg-[#1a1a1f] border border-[#2a2a35] rounded-full text-[#4f7ef8]">{history.length}</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {history.map((item) => (
                    <motion.button
                      whileHover={{ y: -5 }}
                      key={item.id}
                      onClick={() => {
                        setCode(item.originalCode);
                        setResult(item.result);
                        setStatus('completed');
                        setCurrentLang(item.language);
                        setFilename(item.filename);
                        setActiveTab('workspace');
                      }}
                      className="group text-left bg-[#141417] border border-[#2a2a35] rounded-3xl p-6 hover:border-[#4f7ef8]/50 transition-all space-y-4"
                    >
                      <div className="flex justify-between items-start">
                        <div className="px-2 py-0.5 bg-[#4f7ef8]/10 text-[#4f7ef8] border border-[#4f7ef8]/20 rounded-full text-[8px] font-black uppercase tracking-widest">
                          {item.language}
                        </div>
                        <span className="text-[10px] font-bold text-[#606078]">{item.timestamp}</span>
                      </div>
                      <div>
                        <h4 className="font-bold text-sm text-[#e8e8f0] group-hover:text-[#4f7ef8] transition-colors">{item.filename}</h4>
                        <p className="text-xs text-[#9090a8] line-clamp-2 mt-1 font-light leading-relaxed">{item.bug}</p>
                      </div>
                      <div className="pt-4 border-t border-[#2a2a35] flex items-center justify-between">
                         <span className="text-[10px] font-black uppercase text-[#606078]">Reliability</span>
                         <span className="text-[10px] font-bold text-green-400">{item.result.confidence}%</span>
                      </div>
                    </motion.button>
                  ))}
                  {history.length === 0 && (
                    <div className="col-span-full py-20 text-center space-y-4 opacity-40">
                       <Clock className="w-12 h-12 mx-auto text-[#606078]" />
                       <p className="text-sm font-bold uppercase tracking-widest text-[#606078]">No Records Found</p>
                    </div>
                  )}
                </div>
             </motion.div>
          )}

          {activeTab === 'overview' && (
            <motion.div 
              key="overview"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              className="py-10 space-y-20"
            >
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
                 <div className="space-y-8">
                   <div className="space-y-4">
                     <h2 className="text-5xl font-black leading-tight tracking-tighter">Automated Neural Program Repair.</h2>
                     <p className="text-[#9090a8] text-xl font-light leading-relaxed">
                       Code Sentinel abstracts the entire debugging workflow into a single-pass neural process, eliminating human error and manual investigation.
                     </p>
                   </div>
                   
                   <div className="grid grid-cols-2 gap-6">
                     {[
                       { title: 'Semantic Flow', desc: 'Goes beyond regex to understand logical intent', icon: Search },
                       { title: 'Heuristic Synthesis', desc: 'Optimal patch generation for complex scenarios', icon: Lightbulb },
                       { title: 'Isolated Sandbox', desc: 'Verifies code without side-effects', icon: Shield },
                       { title: 'Cloud Persistence', desc: 'Secure history storage for entire teams', icon: Database },
                     ].map(f => (
                       <div key={f.title} className="p-6 bg-[#141417] border border-[#2a2a35] rounded-3xl relative overflow-hidden group">
                         <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-30 transition-opacity">
                            <f.icon className="w-12 h-12" />
                         </div>
                         <h4 className="font-bold text-[#e8e8f0] mb-2">{f.title}</h4>
                         <p className="text-[11px] text-[#606078] leading-relaxed">{f.desc}</p>
                       </div>
                     ))}
                   </div>
                 </div>

                 <div className="relative group">
                    <div className="absolute -inset-10 bg-blue-500/10 rounded-full blur-[100px] opacity-50"></div>
                    <div className="relative bg-[#141417] border border-[#2a2a35] rounded-[3rem] p-12 overflow-hidden">
                       <div className="absolute top-0 right-0 w-64 h-64 bg-purple-500/10 blur-[80px]"></div>
                       <blockquote className="text-3xl font-serif italic text-blue-100/80 leading-snug">
                         "The next era of software engineering isn't just about building faster, it's about building systems that heal themselves."
                       </blockquote>
                       <div className="mt-10 flex items-center gap-4">
                          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-blue-500 to-purple-500"></div>
                          <div>
                            <p className="text-sm font-bold">Dr. Alaric Vance</p>
                            <p className="text-[10px] font-black uppercase text-[#606078] tracking-widest">Chief Neural Architect</p>
                          </div>
                       </div>
                    </div>
                 </div>
              </div>

              <div className="text-center py-20 bg-gradient-to-b from-transparent via-blue-500/5 to-transparent rounded-[4rem]">
                 <p className="text-[10px] font-black uppercase tracking-[0.5em] text-[#4f7ef8] mb-6">Benchmarks</p>
                 <div className="grid grid-cols-2 md:grid-cols-4 gap-10">
                    {[
                      { label: 'Repair Acc', val: '94.2%' },
                      { label: 'MTTR Reduc', val: '80%' },
                      { label: 'Language Core', val: '12+' },
                      { label: 'Latency', val: '< 2s' },
                    ].map(st => (
                      <div key={st.label} className="space-y-1">
                        <div className="text-5xl font-black tracking-tighter text-white">{st.val}</div>
                        <div className="text-[10px] font-bold text-[#606078] uppercase tracking-widest">{st.label}</div>
                      </div>
                    ))}
                 </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <footer className="mt-20 border-t border-[#2a2a35] py-16 px-6 relative overflow-hidden">
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-full h-[1px] bg-gradient-to-r from-transparent via-[#4f7ef8]/50 to-transparent"></div>
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-4">
            <Zap className="w-6 h-6 text-[#4f7ef8]" />
            <span className="font-black text-lg tracking-tighter">CODE <span className="text-[#4f7ef8]">SENTINEL</span></span>
          </div>
          <p className="text-[10px] font-bold text-[#606078] uppercase tracking-[0.2em]">Crafted for the Neural Age · v2.0.4 Premium</p>
          <div className="flex gap-8">
            {['Architecture', 'Privacy', 'Neural_Node', 'API'].map(link => (
              <a key={link} href="#" className="text-[10px] font-bold text-[#606078] hover:text-[#4f7ef8] transition-colors uppercase tracking-widest">_{link}</a>
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
}

function BoxIcon({ className }: { className?: string }) {
  return (
    <svg 
      className={className} 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
    >
      <path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z" />
      <path d="m3.3 7 8.7 5 8.7-5" />
      <path d="M12 22V12" />
    </svg>
  );
}
